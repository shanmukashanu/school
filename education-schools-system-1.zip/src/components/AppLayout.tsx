import React, { useState } from 'react';
import { SchoolProvider } from '@/context/SchoolContext';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/sections/HeroSection';
import { AboutSection } from '@/components/sections/AboutSection';
import { AdmissionsSection } from '@/components/sections/AdmissionsSection';
import { FeesSection } from '@/components/sections/FeesSection';
import { AcademicsSection } from '@/components/sections/AcademicsSection';
import { BlogSection } from '@/components/sections/BlogSection';
import { GallerySection } from '@/components/sections/GallerySection';
import { ContactSection } from '@/components/sections/ContactSection';
import { NoticesSection } from '@/components/sections/NoticesSection';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';
import { LoginModal } from '@/components/auth/LoginModal';
import { AdminDashboard } from '@/components/dashboard/AdminDashboard';

const AppContent: React.FC = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);

  const handleNavigate = (page: string) => {
    if (page === 'dashboard') {
      setShowDashboard(true);
      return;
    }
    setShowDashboard(false);
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (showDashboard) {
    return (
      <div>
        <div className="bg-white shadow px-4 py-2 flex justify-between items-center">
          <button
            onClick={() => setShowDashboard(false)}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Website
          </button>
        </div>
        <AdminDashboard />
      </div>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <>
            <HeroSection onNavigate={handleNavigate} />
            <NoticesSection />
            <AboutSection onNavigate={handleNavigate} />
            <TestimonialsSection />
            <BlogSection />
          </>
        );
      case 'about':
        return <AboutSection onNavigate={handleNavigate} />;
      case 'academics':
        return <AcademicsSection />;
      case 'admissions':
        return <AdmissionsSection />;
      case 'fees':
        return <FeesSection />;
      case 'gallery':
        return <GallerySection />;
      case 'blog':
        return <BlogSection />;
      case 'contact':
        return <ContactSection />;
      default:
        return (
          <>
            <HeroSection onNavigate={handleNavigate} />
            <NoticesSection />
            <AboutSection onNavigate={handleNavigate} />
            <TestimonialsSection />
            <BlogSection />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header 
        currentPage={currentPage} 
        onNavigate={handleNavigate} 
        onOpenLogin={() => setLoginModalOpen(true)}
      />
      
      <main>
        {renderPage()}
      </main>
      
      <Footer onNavigate={handleNavigate} />
      
      <LoginModal 
        isOpen={loginModalOpen} 
        onClose={() => setLoginModalOpen(false)} 
      />

      {/* Admin Access Button - For Demo */}
      <button
        onClick={() => setShowDashboard(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-3 rounded-full shadow-lg hover:shadow-xl transition-all flex items-center gap-2 z-50"
      >
        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
        Admin Panel
      </button>
    </div>
  );
};

const AppLayout: React.FC = () => {
  return (
    <SchoolProvider>
      <AppContent />
    </SchoolProvider>
  );
};

export default AppLayout;

import React, { useState, useEffect } from 'react';
import { useSchool } from '@/context/SchoolContext';
import { supabase } from '@/lib/supabase';
import { Card, StatCard } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { AdmissionEnquiry, FeeEnquiry, ContactEnquiry } from '@/types';

export const AdminDashboard: React.FC = () => {
  const { schools, selectedSchool, stats, refreshStats } = useSchool();
  const [activeTab, setActiveTab] = useState('overview');
  const [admissionEnquiries, setAdmissionEnquiries] = useState<AdmissionEnquiry[]>([]);
  const [feeEnquiries, setFeeEnquiries] = useState<FeeEnquiry[]>([]);
  const [contactEnquiries, setContactEnquiries] = useState<ContactEnquiry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [selectedSchool]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const schoolFilter = selectedSchool ? { school_id: selectedSchool.id } : {};

      const [admRes, feeRes, contactRes] = await Promise.all([
        supabase.from('admission_enquiries').select('*').match(schoolFilter).order('created_at', { ascending: false }).limit(10),
        supabase.from('fee_enquiries').select('*').match(schoolFilter).order('created_at', { ascending: false }).limit(10),
        supabase.from('contact_enquiries').select('*').match(schoolFilter).order('created_at', { ascending: false }).limit(10)
      ]);

      if (admRes.data) setAdmissionEnquiries(admRes.data);
      if (feeRes.data) setFeeEnquiries(feeRes.data);
      if (contactRes.data) setContactEnquiries(contactRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateEnquiryStatus = async (table: string, id: string, status: string) => {
    try {
      await supabase.from(table).update({ status }).eq('id', id);
      fetchData();
      refreshStats();
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: 'admissions', label: 'Admission Enquiries', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
    { id: 'fees', label: 'Fee Enquiries', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: 'contacts', label: 'Contact Messages', icon: 'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-700';
      case 'contacted': return 'bg-yellow-100 text-yellow-700';
      case 'scheduled': return 'bg-purple-100 text-purple-700';
      case 'admitted': return 'bg-green-100 text-green-700';
      case 'rejected': return 'bg-red-100 text-red-700';
      case 'pending': return 'bg-orange-100 text-orange-700';
      case 'resolved': return 'bg-green-100 text-green-700';
      case 'unread': return 'bg-blue-100 text-blue-700';
      case 'read': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-500">
                {selectedSchool ? selectedSchool.name : 'All Schools'} - Management Portal
              </p>
            </div>
            <Button onClick={fetchData} variant="outline">
              <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={tab.icon} />
              </svg>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <StatCard
                title="Total Students"
                value={stats.students}
                color="bg-blue-100"
                icon={
                  <svg className="w-6 h-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                }
              />
              <StatCard
                title="Total Teachers"
                value={stats.teachers}
                color="bg-green-100"
                icon={
                  <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                }
              />
              <StatCard
                title="Admission Enquiries"
                value={stats.admissionEnquiries}
                color="bg-purple-100"
                icon={
                  <svg className="w-6 h-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                }
              />
              <StatCard
                title="Fee Enquiries"
                value={stats.feeEnquiries}
                color="bg-orange-100"
                icon={
                  <svg className="w-6 h-6 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                }
              />
            </div>

            {/* Schools Overview */}
            <Card className="p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Schools Overview</h3>
              <div className="grid md:grid-cols-3 gap-4">
                {schools.map((school) => (
                  <div
                    key={school.id}
                    className="p-4 rounded-xl border-2 border-gray-100 hover:border-blue-200 transition-colors"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: school.theme_color }}
                      >
                        {school.code}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{school.name}</p>
                        <p className="text-sm text-gray-500">Est. {school.established_year}</p>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>{school.address}</p>
                      <p>{school.phone}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* Admission Enquiries Tab */}
        {activeTab === 'admissions' && (
          <Card className="overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900">Admission Enquiries</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Student</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Parent</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Contact</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Class</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {admissionEnquiries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                        No admission enquiries yet
                      </td>
                    </tr>
                  ) : (
                    admissionEnquiries.map((enquiry) => (
                      <tr key={enquiry.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <p className="font-medium text-gray-900">{enquiry.student_name}</p>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{enquiry.parent_name}</td>
                        <td className="px-6 py-4">
                          <p className="text-gray-600">{enquiry.email}</p>
                          <p className="text-sm text-gray-400">{enquiry.phone}</p>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{enquiry.class_applying}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(enquiry.status || 'new')}`}>
                            {enquiry.status || 'new'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            value={enquiry.status || 'new'}
                            onChange={(e) => updateEnquiryStatus('admission_enquiries', enquiry.id!, e.target.value)}
                            className="text-sm border border-gray-200 rounded-lg px-2 py-1"
                          >
                            <option value="new">New</option>
                            <option value="contacted">Contacted</option>
                            <option value="scheduled">Scheduled</option>
                            <option value="admitted">Admitted</option>
                            <option value="rejected">Rejected</option>
                          </select>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* Fee Enquiries Tab */}
        {activeTab === 'fees' && (
          <Card className="overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900">Fee Enquiries</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Contact</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Message</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {feeEnquiries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                        No fee enquiries yet
                      </td>
                    </tr>
                  ) : (
                    feeEnquiries.map((enquiry) => (
                      <tr key={enquiry.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium text-gray-900">{enquiry.parent_name}</td>
                        <td className="px-6 py-4">
                          <p className="text-gray-600">{enquiry.email}</p>
                          <p className="text-sm text-gray-400">{enquiry.phone}</p>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{enquiry.enquiry_type}</td>
                        <td className="px-6 py-4 text-gray-600 max-w-xs truncate">{enquiry.message}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(enquiry.status || 'pending')}`}>
                            {enquiry.status || 'pending'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            value={enquiry.status || 'pending'}
                            onChange={(e) => updateEnquiryStatus('fee_enquiries', enquiry.id!, e.target.value)}
                            className="text-sm border border-gray-200 rounded-lg px-2 py-1"
                          >
                            <option value="pending">Pending</option>
                            <option value="contacted">Contacted</option>
                            <option value="resolved">Resolved</option>
                          </select>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {/* Contact Messages Tab */}
        {activeTab === 'contacts' && (
          <Card className="overflow-hidden">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900">Contact Messages</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Contact</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Subject</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Message</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {contactEnquiries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                        No contact messages yet
                      </td>
                    </tr>
                  ) : (
                    contactEnquiries.map((enquiry) => (
                      <tr key={enquiry.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium text-gray-900">{enquiry.name}</td>
                        <td className="px-6 py-4">
                          <p className="text-gray-600">{enquiry.email}</p>
                          <p className="text-sm text-gray-400">{enquiry.phone}</p>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{enquiry.subject}</td>
                        <td className="px-6 py-4 text-gray-600 max-w-xs truncate">{enquiry.message}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor((enquiry as any).status || 'unread')}`}>
                            {(enquiry as any).status || 'unread'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            value={(enquiry as any).status || 'unread'}
                            onChange={(e) => updateEnquiryStatus('contact_enquiries', enquiry.id!, e.target.value)}
                            className="text-sm border border-gray-200 rounded-lg px-2 py-1"
                          >
                            <option value="unread">Unread</option>
                            <option value="read">Read</option>
                            <option value="resolved">Resolved</option>
                          </select>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};
